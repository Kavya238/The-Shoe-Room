import React from "react";
import "./header.css";

import Menu from "../Home/Banner/Menu";

const index = () => {
  return (
    <div className="header-wrapper">
      <Menu />
    </div>
  );
};

export default index;
