import React from "react";

const index = () => {
  return <div>contact compnent</div>;
};

export default index;
