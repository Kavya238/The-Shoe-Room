import React from "react";
import "./App.css";
import "./responsive.css";
import Home from "./components/Home";

function App() {
  return <Home />;
}

export default App;
